package com.veribay.logos.controller;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.veribay.logos.model.Logos;
import com.veribay.logos.service.LogosService;

@RestController
@CrossOrigin
public class LogosController {

	@Autowired
	private LogosService service;

	@PostMapping("/registerLogo")
	public String registerUser(@RequestParam("logo") MultipartFile logo) throws IOException {
		
		Logos logos=new Logos();		
		logos.setId(UUID.randomUUID());		
		ByteBuffer logoBuffer = ByteBuffer.wrap(logo.getBytes());
		logos.setLogo(logoBuffer);
		service.registerLogo(logos);
		return "Registered Successfully with id : " + logos.getId();
	}

	@GetMapping("/getLogos")
	public Iterable<Logos> getAllLogos() {
		return service.getAllLogos();
	}

}
