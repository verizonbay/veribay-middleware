package com.veribay.logos.model;

import java.nio.ByteBuffer;
import java.util.UUID;

import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import com.datastax.driver.core.DataType.Name;

@Table(value = "logos")
public class Logos {

	@PrimaryKey
	private UUID id;

	@CassandraType(type = Name.BLOB)
	private ByteBuffer logo;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public ByteBuffer getLogo() {
		return logo;
	}

	public void setLogo(ByteBuffer logo) {
		this.logo = logo;
	}

}
