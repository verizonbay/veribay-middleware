package com.veribay.logos.repository;


import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;

import com.veribay.logos.model.Logos;

public interface LogosRepository extends CassandraRepository<Logos, UUID>{

}
