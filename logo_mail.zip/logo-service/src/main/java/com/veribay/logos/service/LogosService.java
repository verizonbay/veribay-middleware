package com.veribay.logos.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veribay.logos.model.Logos;
import com.veribay.logos.repository.LogosRepository;

@Service
public class LogosService {

	@Autowired
	private LogosRepository repository;
	
	public String registerLogo(Logos logo) {
		repository.save(logo);
		return "Registered Successfully with id : "+logo.getId();
	}
	
	public Iterable<Logos> getAllLogos(){
		return repository.findAll();
	}
	

}
