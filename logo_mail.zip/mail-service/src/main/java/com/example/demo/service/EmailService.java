package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.model.Email;

@Service
public class EmailService {
	@Autowired
	private JavaMailSender javaMailSender;

	public String sendEmail(Email email) {
		SimpleMailMessage msg = new SimpleMailMessage();

		msg.setTo(email.getEmail());
		msg.setSubject(email.getSubject());
		msg.setText(email.getText());
		javaMailSender.send(msg);
		return "Success";
	}

//	void sendEmailWithAttachment() throws MessagingException, IOException {
//		MimeMessage msg = javaMailSender.createMimeMessage();
//		MimeMessageHelper helper = new MimeMessageHelper(msg, true);
//		helper.setTo("projectvbay@gmail.com");
//		helper.setSubject("message from Spring Boot");
//		helper.setText("<h1>Check attachment for image!</h1>", true);
//		helper.addAttachment("my_photo.png", new ClassPathResource("download.png"));
//
//		javaMailSender.send(msg);
//
//	}
}
