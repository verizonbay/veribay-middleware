package com.veribay.sales.controller;

import java.io.IOException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.veribay.sales.model.Sales;
import com.veribay.sales.service.SalesService;

@RestController
@CrossOrigin
public class SalesController {

	@Autowired
	private SalesService service;

	@PostMapping("/registerSale")
	public String registerUser(@RequestBody Sales sale 		) throws IOException {

		UUID uuid = UUID.randomUUID();
		sale.setId(uuid);
		

		service.registerSale(sale);
		return "Registered Successfully with id : " + sale.getId();
	}

	@GetMapping("/getSales")
	public Iterable<Sales> getAllSales() {
		return service.getAllSales();
	}

}
