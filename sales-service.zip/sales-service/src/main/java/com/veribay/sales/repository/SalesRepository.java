package com.veribay.sales.repository;


import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;

import com.veribay.sales.model.Sales;

public interface SalesRepository extends CassandraRepository<Sales, UUID>{

}
