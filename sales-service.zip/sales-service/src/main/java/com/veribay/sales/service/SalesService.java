package com.veribay.sales.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veribay.sales.model.Sales;
import com.veribay.sales.repository.SalesRepository;

@Service
public class SalesService {

	@Autowired
	private SalesRepository repository;
	
	public String registerSale(Sales sale) {
		repository.save(sale);
		return "Registered Successfully with id : "+sale.getId();
	}
	
	public Iterable<Sales> getAllSales(){
		return repository.findAll();
	}
	

}
