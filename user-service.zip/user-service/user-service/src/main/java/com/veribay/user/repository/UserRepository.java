package com.veribay.user.repository;


import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;

import com.veribay.user.model.Users;

public interface UserRepository extends CassandraRepository<Users, UUID>{

}
