package com.veribay.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;
import java.util.UUID;

import com.veribay.model.Card;
import com.veribay.service.CardService;

@RestController
@CrossOrigin
public class CardController {

	@Autowired
	private CardService service;
	
	@PostMapping("/addCard")
	public String registerCard(@RequestBody Card card) {
		UUID uuid = UUID.randomUUID();
		card.setId(uuid);
		service.registerCard(card);
		return service.registerCard(card);
	}
	
	@GetMapping("/getAllCards")
	public List<Card> getAllCards(){
		return service.getAllCards();
	}
}
