package com.veribay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veribay.model.Card;
import com.veribay.repository.CardRepository;


@Service
public class CardService {
	
	@Autowired
	private CardRepository repository;
	

	public String registerCard(Card card) {
		repository.save(card);
		return "Product Added Successfully with id : "+card.getId();
	}
	
	public List<Card> getAllCards(){
		return repository.findAll();
	}
	
}
